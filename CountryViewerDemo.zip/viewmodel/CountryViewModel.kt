package com.example.countryviewerdemo.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.countryviewerdemo.model.Country
import com.example.countryviewerdemo.repository.CountryRepository
import kotlinx.coroutines.launch

class CountryViewModel : ViewModel() {
    private val _countries = MutableLiveData<List<Country>>()
    val countries: LiveData<List<Country>> = _countries

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> = _error

    private val repository = CountryRepository()

    fun fetchCountries() {
        viewModelScope.launch {
            val result = repository.getCountries()
            result.onSuccess { _countries.value = it }
                .onFailure { _error.value = it.message ?: "Unknown Error" }
        }
    }
}
package com.example.countryviewerdemo

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.countryviewerdemo.adapter.CountryAdapter
import com.example.countryviewerdemo.viewmodel.CountryViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: CountryViewModel
    private lateinit var adapter: CountryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        adapter = CountryAdapter()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        viewModel = ViewModelProvider(this)[CountryViewModel::class.java]

        viewModel.countries.observe(this) {
            adapter.submitList(it)
        }

        viewModel.error.observe(this) {
            Log.e("MainActivity", "Error fetching countries: $it")
            Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
        }

        viewModel.fetchCountries()
    }
}
package com.example.countryviewerdemo.repository

import com.example.countryviewerdemo.model.Country
import com.example.countryviewerdemo.network.ApiService
import retrofit2.HttpException

class CountryRepository {
    private val apiService = ApiService.instance

    suspend fun getCountries(): Result<List<Country>> {
        return try {
            val response = apiService.getCountries()
            if (response.isSuccessful) {
                Result.success(response.body() ?: emptyList())
            } else {
                Result.failure(Exception("Error: ${response.message()}"))
            }
        } catch (e: HttpException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}